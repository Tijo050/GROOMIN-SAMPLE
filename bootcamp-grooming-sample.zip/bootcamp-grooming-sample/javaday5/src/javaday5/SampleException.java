package javaday5;

import java.util.Scanner;

public class SampleException {

	public static void main(String[] args) {
		
		Scanner scan=new Scanner(System.in);
		
		try
		{
		int a=scan.nextInt();
		int b=scan.nextInt();
		int ans=a/b; //throw the exception
		
		System.out.println(ans);
		
	
		}
		catch(Exception excep) //catch the exception thrown by line no 15
		{
			System.out.println("Some error in numbers" + excep );
		}
		
		System.out.println("Welcome to my Session");
	}

}
