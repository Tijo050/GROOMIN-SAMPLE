package javaday5;

class Emp
{
	String empname;
	int salary;
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	void setData(String nm, int sal) throws InvalidSalaryException
	{
		InvalidSalaryException obj=new InvalidSalaryException("salary cantbe negatie");
		
		if(sal<=0)
		//	throw new InvalidSalaryException("salary cant be negative"); //invoke or raise exception
		throw obj;
		
		this.empname=nm;
		this.salary=sal;
	}
}



public class SampleUserException {

	public static void main(String[] args)   {
Emp emp1 =new Emp();
try
{
 emp1.setData("John", -5000);
}
catch(InvalidSalaryException excep)
{
	System.out.println(excep);
}
finally
{
	System.out.println("hai");
}

 System.out.println("done");
	}

}
