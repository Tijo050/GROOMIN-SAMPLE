package javaday5;

public class InvalidSalaryException extends Exception {
	
	InvalidSalaryException(String msg)
	{
		super(msg);
	}

}
