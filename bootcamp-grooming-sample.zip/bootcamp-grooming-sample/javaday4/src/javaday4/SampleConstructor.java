package javaday4;

 class Person
{
	String eName;
	String adnumber;
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public String getAdnumber() {
		return adnumber;
	}
	public void setAdnumber(String adnumber) {
		this.adnumber = adnumber;
	}
   void display()
   {
	   System.out.println("welcome");
   }

	Person()
	{
		System.out.println("I am person - parent constructor with no arg");
	}
	
	Person(String name,String adhar)
	{
		System.out.println(" i am person - parent construct with arguemnt");
		this.eName=name;
		this.adnumber=adhar;
		
	}
	
	public String toString()
	{
		return " employee name" + eName + " adnumber" + adnumber;
	}
	
}

class Mentor extends Person
{
	String subject;
	int yrsofexpr;
	 Mentor()
	 {
		 super("Tharani","UX0102");
		 System.out.println("I am mentor - child construc with no arg");
		  subject="Comp. Sci";
		  yrsofexpr=15;
	 }
	 Mentor(String sub,int yr)
	 {
		 // super("Padma","AUX0102"); -- if super is not used, then by default parent classes no argument constructor will be called
		 
		 System.out.println("I am mentor - child construc with Argument");
		 this.subject=sub;
		 this.yrsofexpr=yr;
	 }
	 public String toString()
	 {
		 return "subject " + subject + " experience " + yrsofexpr;
	 }
	 
	void display()
	{
		super.display();
		System.out.println("mentor sess closed");
	}
}


public class SampleConstructor {
	public static void main(String[] args) {
		
		Mentor mentor1=new Mentor();
		//System.out.println(mentor1);
		mentor1.display();
		
		Mentor mentor2=new Mentor("Prof skills",15);
		System.out.println(mentor2);
		

		
		
//		
//		Person person1=new Person("Balu","BD244"); // constructor with no argument is called
//		person1.seteName("Arun");  // or person1.eName="Arun";  but not good practice
//		
//		System.out.println(person1); //	same as 	System.out.println(person1.toString());
//		
//		Person person3=new Person("Anju","AD24993");
//	  System.out.println(person3);
//		
//		
//		
//		Person person2=new Person();
//		
//		System.out.println(person2);
//		
		
		

	}

}
