class Water
{
	int qty=1;
	 String cname="MN Company";
	int price=35;

	
	 void display()
	{
		System.out.println("Compnayname " + cname + " price" + price );
	}
	 void calcuPrice()
	 {
		 System.out.println("amount is " + qty*price);
	 }
	}
class FreshFruit extends Water
{
	 String fruitname;
	 String color;
	void setData()
	{
		
		fruitname="Apple";
		color="palered";
	}
	 void getFruitdata()
	{
	   display();	
		System.out.println("Fruit name " + fruitname + " color " + color);
	}
	//method overriding
	void calcuPrice()
	{
		
		System.out.println("Amount for freshfruit juice " + qty *price + 5 );
	 
	}
}

class CoolDrink extends Water
{
	 String drinkName;
	  String type;
	 
	  void setDetails()
	  {
		  drinkName="Maaza";
		  type="Paper container";
		  cname="KLM company";
		  qty=1;
		  price=20;
	  }
	  
	  void getData()
	  {
		  display();
		  System.out.println(" drinkname" + drinkName);
	  }
	  void calcuPrice()
	  {
		  System.out.println("Amount for cooldrink " + qty *price +18/100);
	  }
}

public class SampleInheri {

	public static void main(String[] args) {
 		FreshFruit freshobj1=new FreshFruit();
 
 	
 		
 		
 		
		freshobj1.setData();
		freshobj1.getFruitdata();
		freshobj1.calcuPrice();
		
		CoolDrink coolobj=new CoolDrink();
		coolobj.setDetails();
		coolobj.calcuPrice();
		
		coolobj.getData();
				
		
	}

}
