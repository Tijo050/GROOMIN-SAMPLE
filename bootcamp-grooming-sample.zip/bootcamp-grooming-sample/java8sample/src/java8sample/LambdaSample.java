package java8sample;


interface imarket
{
	void displayProduct();
	void getPrice(int qty,int amount);
	default void  locationDetails()
	{
		System.out.println("KR Pura Market, BLore");
	}
}

class Supermarket implements imarket
{
	@Override
	public void displayProduct() {
	 System.out.println("products are Vegetables and Fruits");
		
	}

	@Override
	public void getPrice(int qty, int amount) {
	   System.out.println("Price is " + qty*amount);
		
	}
}

public class LambdaSample {

	public static void main(String[] args) {

//imarket marobj=new Supermarket();
		
		imarket foodmarket=new imarket()
							{

								@Override
								public void displayProduct() {
								 System.out.println("products are Vegetables and Fruits");
									
								}

								@Override
								public void getPrice(int qty, int amount) {
								   System.out.println("Price is " + qty*amount);
									
								}
			
							};
							
							

			
			
		imarket digitalmarket=new imarket()
				{

					@Override
					public void displayProduct() {
						System.out.println("products are ram and mouse");
						
					}

					@Override
					public void getPrice(int qty, int amount) {
						// TODO Auto-generated method stub
						
					}
			
				};
		
//	imarket markeobj2=new Supermarket();
//	imarket markeobj3=new Supermarket();
//	
	
			}
							
		
	

}
