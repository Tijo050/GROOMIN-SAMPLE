package java8sample;


interface iAdmin
{
	void purchaseBook(String bk);
	void viewBook();
}

@FunctionalInterface
interface iUser
{
	void viewBook();
	 
	public default void showRules()
	{
		System.out.println("You have to be vaccinated for entering into library");
	}
	
	public default  void formFill()
	{
		System.out.println("Submit your forms ");
	}
	
}


class Book implements iAdmin,iUser
{
	String bookname;
	String author;
	
	 
	public Book()
	{
		bookname="windows";
		author="grill brik";
	}
  public void purchaseBook(String bookname)
   {
	   this.bookname=bookname;
   }
   public void viewBook()
   {
	   System.out.println("book" + bookname + "Author " + author);
   }
 }



public class BookStoreSample {

	public static void main(String[] args) {
		 
 System.out.println("admin");
 iAdmin bookadmin=new Book();
   bookadmin.purchaseBook("ASP");
   bookadmin.viewBook();
   //bookadmin.
 
 System.out.println("user trans");
 
 iUser bookuser=new Book();
 bookuser.viewBook();
 bookuser.showRules();
 bookuser.formFill();
}
}

