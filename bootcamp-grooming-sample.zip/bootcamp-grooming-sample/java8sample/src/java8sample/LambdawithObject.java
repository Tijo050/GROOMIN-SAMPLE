package java8sample;

interface iprocessemp
{
	int checkTax(Employee emp);
}

public class LambdawithObject {

	public static void main(String[] args) {
	
		iprocessemp empprocess= (e)-> {
						if (e.getSalary()>5000)
							return e.getSalary()*10/100;
						else
							return e.getSalary()*5/100;
		};
		
	
	Employee empobj	=new Employee(10,"Paul",40000);
	
	System.out.println(empprocess.checkTax(empobj));
		
		
		
	}

}
