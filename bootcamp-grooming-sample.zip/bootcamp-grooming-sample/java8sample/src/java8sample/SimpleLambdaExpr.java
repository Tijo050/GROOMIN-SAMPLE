package java8sample;

@FunctionalInterface
interface iproduct
{

	int getPrice(int qty,int amount);
	

	
	default void  locationDetails()
	{
		System.out.println("KR Pura Market, BLore");
	}
	
	default	void displayProduct()
	{
		System.out.println("Mobile, Food items, Digital items all avaialble");
		
	}
}


public class SimpleLambdaExpr {

	public static void main(String[] args) {

		//using anynomous
	iproduct productmobile=new iproduct()
							{

								@Override
								public int getPrice(int qty, int amount) {
									return qty*amount;
									
								}
		
							};
			int ans=productmobile.getPrice(3, 15000);
			System.out.println(ans);	
			
	//using lambda
			
  iproduct producthousehold= (qty,amount)->qty*amount;
  
	iproduct productbag= (q,amt)->{ 
					 if(q>10)
					return q*amt;
					 else
						 return 0;
				};
	
				
int ans1=productbag.getPrice(3, 15000);
System.out.println(ans1);
		
	}

}
