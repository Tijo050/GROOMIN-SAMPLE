package java8sample;

interface iperson
{
	boolean validatePassword(String s1,String s2);
}

interface irules
{
	void showRule();
}

public class SimpleLambda2 {
	
	public static void main(String[] args) {

		irules rule1= ()-> System.out.println("Welcome " );
		
		rule1.showRule();
		
		iperson person= (un,pwd)-> {
									if(  (un.equals("admin")) && (pwd.equals("password"))  ) 
										return true;
									else
										return false;
							
									};
									
		boolean res=person.validatePassword("Mary", "pass");	
		
		if (res)
			System.out.println("Welcome");
		else
			System.out.println("invalid");
									
									
	}

}
