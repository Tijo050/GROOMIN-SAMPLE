package javaday10;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class BasicReadStream {

	public static void main(String[] args) throws Exception {

		FileReader filereadobj=new FileReader("hello.txt");
		
		BufferedReader breadobj=new BufferedReader(filereadobj);
		
		
		
//		char[] data=new char[100];
//		filereadobj.read(data);
		
		String line;
		
		
		while(  (line=breadobj.readLine())!=null )
		{
		System.out.println(line);
		}
		
		
	}

}
