package javaday10;

import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;

public class BasicStream {

	public static void main(String[] args) throws Exception {
	
//		FileInputStream 
		FileWriter filewrite=null;
		try {
			//
			
			//File fileobj=new File("e:\\ust\\abc.txt");
			 //filewrite=new FileWriter(fileobj,true);
			
			filewrite=new FileWriter("hello.txt",true);
			BufferedWriter bf=new BufferedWriter(filewrite);
			
			
		
//			DataOutputStream dobj=new DataOutputStream(filewrite);
			
			
			
		bf.write("\n Good Day");
		bf.write("\n have great time");
		
			bf.flush();
			System.out.println("File Created");
			
		}
		
		catch (Exception e) {
			System.out.println(e);
	
		}
		finally
		{
			 filewrite.close();
		}
		
		

	}

}
