package javaday10;

import java.io.Serializable;

public class Player implements Serializable {
 String playerName;
 String country;
 
 public Player(String pname,String cntry)
 {
	 this.playerName=pname;
	 this.country=cntry;
 }
public String getPlayerName() {
	return playerName;
}
public void setPlayerName(String playerName) {
	this.playerName = playerName;
}
public String getCountry() {
	return country;
}
public void setCountry(String country) {
	this.country = country;
}
 public String toString()
 {
	 return " name is " + playerName + " counry " +  country;
 }
	
}
