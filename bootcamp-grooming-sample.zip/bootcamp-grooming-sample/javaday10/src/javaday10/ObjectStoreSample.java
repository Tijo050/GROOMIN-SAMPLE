package javaday10;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class ObjectStoreSample {

	public static void main(String[] args) throws Exception {

		FileOutputStream fileobj=new FileOutputStream("indiaplayer.txt");
		
		
		ObjectOutputStream objout=new ObjectOutputStream(fileobj);
		
		Player playernew=new Player("Andrew","Aus");
		
		objout.writeObject(playernew);

		System.out.println("Object stored");
		
		fileobj.close();
	}

}
