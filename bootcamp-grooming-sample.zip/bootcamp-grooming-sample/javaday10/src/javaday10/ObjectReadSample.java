package javaday10;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;

public class ObjectReadSample {

	public static void main(String[] args) throws Exception {
	
		FileInputStream fileinput=new FileInputStream("indiaplayer.txt");
		ObjectInputStream objinput=new ObjectInputStream(fileinput);
		
	Player perobj=(Player)objinput.readObject();
		
	System.out.println(perobj.getCountry());
	
	//	FileReader filereader=new FileReader("india")
		

	}

}
