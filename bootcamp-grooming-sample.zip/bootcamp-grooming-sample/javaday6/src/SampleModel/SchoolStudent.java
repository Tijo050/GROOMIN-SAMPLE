package SampleModel;

import javaday6.Student;

public class SchoolStudent extends Student {

	void test()
	{
		name="anu";
		addr="delhi";
	}
	
}

class Mymain
{
	void check()
	{
		Student stobj=new Student();
		
	}
	
}
