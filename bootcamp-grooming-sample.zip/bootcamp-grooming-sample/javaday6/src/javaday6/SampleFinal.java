package javaday6;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

final class Book
{
	int bookno=10;
	final String bookname="Java8 Ref";

	void setData() throws Exception 
	{
		bookno=15;
		 

	
		 
	}
	
	final void printall()
	{
		System.out.println("bookname is " + bookname);
	}
	
}


class Maths  
{
	
// the below override is not possib
//	void printall()
//	{
//		System.out.println("maths class" + bookname);
//	}
	
	
	
}

public class SampleFinal {

	public static void main(String[] args) {
		Book bookobj=new Book();
		bookobj.bookno=13;
		
		
		//bookobj.bookname="Lara";

		
		Maths mathobj=new Maths();
	//	mathobj.printall();
	}

}
