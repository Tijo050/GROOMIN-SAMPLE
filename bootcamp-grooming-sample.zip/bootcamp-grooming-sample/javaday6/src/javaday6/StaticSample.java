package javaday6;


class Emp
{
	int rollno;
	static String companyName;

	static
	{
	    companyName="ABC company";
	    System.out.println("compnay" + companyName);
	}
	
	
	public int getRollno()
	{
		return rollno;
	}
	public void setRollno(int rollno) {
		this.rollno = rollno;
	}
	public static String getCompanyName() {
		return companyName;
	}
	public static void setCompanyName(String companyName) {
		Emp.companyName = companyName;
	}
//static method can access only static variables as well as other static methods
	
	static void display()
	{
		
	 
		System.out.println("Company is " +  companyName );
	}
	
	Emp()
	{}
	Emp(int rno)
	{
		rollno=rno;
		
	}
	
	public String toString()
	{
		return "rollno " + rollno + " name " + companyName;
	}
}

class Dept  extends Emp
{
	void print()
	{
		System.out.println(companyName);
	}
	
}


public class StaticSample {

	public static void main(String[] args) {
//
Emp emp1 =new Emp(); //new memory alloted
//
//emp1.setRollno(10);
//emp1.setCompanyName("Stackroute");
//System.out.println(emp1);
//
//
//Emp emp2=new Emp(); // new memory
//
//System.out.println(emp2);
//

//System.out.println(Emp.companyName);

Emp.display();

showall();

	}
	
	static void showall()
	{
		
	}

}
