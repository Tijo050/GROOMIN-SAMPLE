package javaday6;




class CollegeStudent extends Student
{
	
	
	
	 
	   void setData()
	   {
		  // rollno=13;
		   name="Mary";
	   }
	
}

public class AccessSpecifierSample {

	public static void main(String[] args) {
		
		Student stuobj=new Student();
		stuobj.name="arun";

	}

}
