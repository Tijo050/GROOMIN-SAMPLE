package com.stackroute.repo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.stackroute.exception.BookIdNotFoundException;
import com.stackroute.exception.BookidAlreadyExistException;
import com.stackroute.model.Book;

public class BookRepo implements ibookrepo{

	
	public static List<Book> books=new ArrayList<Book>();
	
	
	public BookRepo()
	{
		Book b1=new Book(10,"JAva core");
		Book b2=new Book(20,"ASP");
		Book b3=new Book(30,"Python");
		books.add(b1);
		books.add(b2);
		books.add(b3);
	}
	
	Book findBookbyId(int bookid)
	{
		
		for(Book b : books)
		{
			if (b.getBookid()==bookid)
				return b;
		}
		
		return null;
		
	}
	
	
	//raise exception
	@Override
	public void addBook(Book newbook) throws BookidAlreadyExistException{
		
	
		Book bookresult=findBookbyId(newbook.getBookid());
		
		if(bookresult==null)
	     books.add(newbook);
		else
			throw new BookidAlreadyExistException("duplicate id");
		
	}

	@Override
	public List<Book> viewBooks() {
	 
		return books;
	}

	@Override
	public boolean delBook(int bookid) throws BookIdNotFoundException{
	
		Book bookresult=findBookbyId(bookid);
		if (bookresult==null)
			throw new BookIdNotFoundException("id not found");
		
		boolean ans=false;
	 Iterator<Book> iterate=books.iterator();
	 
	 while(iterate.hasNext())
	 {
			Book bobj=iterate.next();
		   		if(bobj.getBookid()==bookid)
		   		{
		   			iterate.remove();
		   			ans=true;
		   		}
	 }
		
	
	 
		return ans;
	}

	
}
