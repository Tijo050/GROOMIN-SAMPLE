package com.stackroute.repo;

import java.util.List;

import com.stackroute.exception.BookIdNotFoundException;
import com.stackroute.exception.BookidAlreadyExistException;
import com.stackroute.model.Book;

public interface ibookrepo {

	public void addBook(Book newbook) throws BookidAlreadyExistException; 
	public List<Book> viewBooks();
	public boolean delBook(int bookid) throws BookIdNotFoundException;
}
