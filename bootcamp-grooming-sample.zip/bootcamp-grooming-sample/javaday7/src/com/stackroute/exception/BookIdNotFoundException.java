package com.stackroute.exception;

public class BookIdNotFoundException extends Exception{
        public BookIdNotFoundException(String msg)
        {
        		super (msg);
        }
}
