package com.stackroute.exception;
//create exception
public class BookidAlreadyExistException extends Exception {

	public BookidAlreadyExistException(String msg)
	{
		super(msg);
	}
	
}
