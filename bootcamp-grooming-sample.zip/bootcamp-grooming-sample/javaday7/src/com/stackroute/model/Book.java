package com.stackroute.model;

public class Book {

	int bookid;
	String bookname;
	public Book() {}
	public Book(int bid,String bname)
	{
		bookid=bid;
		bookname=bname;
	}
	public int getBookid() {
		return bookid;
	}
	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String toString()
	{
		return " bookid " + bookid + " bookname " + bookname;
	}
}
