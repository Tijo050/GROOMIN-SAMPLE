package com.stackroute.client;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import com.stackroute.exception.BookIdNotFoundException;
import com.stackroute.exception.BookidAlreadyExistException;
import com.stackroute.model.Book;
import com.stackroute.repo.BookRepo;
import com.stackroute.repo.ibookrepo;

public class BookClientMain {

	public static void main(String[] args) throws Exception {

		
		ibookrepo bookrepo=new BookRepo();
		List<Book> bookslist=BookRepo.books;
		
		char ans='y';
		
		while(ans=='y')
		{
		

			
			Scanner scan=new Scanner(System.in);
			
	        int choice=0;
		    
		    System.out.println("1- addbook, 2 - view book 3-delete");
		    choice=scan.nextInt();
		
		switch(choice) {
		case 1:
			System.out.println("enter booid and bookname");
			int id=scan.nextInt();
			String name=scan.next();
			
			
			Book bnew=new Book(id,name);
			
			
			//handle the exception using try catch
			
	    	try {
				bookrepo.addBook(bnew);
			} 
	    	catch (BookidAlreadyExistException e) {
			System.out.println(e);	
			}
			break;
			
		case 2:
			List<Book> booksout=bookrepo.viewBooks();
	    	
			
	    	for(Book b : booksout)
	    		System.out.println(b);
	    	
	    	break;
		case 3:
			 System.out.println("Enter bookid");
			 int bid=scan.nextInt();
			boolean result;
			try {
				result = bookrepo.delBook(bid);
			} 
			catch (BookIdNotFoundException e) {
				 System.out.println(e);
			}
			     
			    
			    break;
			    
			default:
				 break;
		
		} //switch
		
    System.out.println("you want to continue y/n");
    
	    ans=(char) System.in.read();
		}//while
	}

}
