package javaday7;

public class Fruit {

	String name;
	int price;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	Fruit(String fname,int pri)
	{
		name=fname;
		price=pri;
	}
	
	public String toString()
	{
		return "Fruit name " + name + " Price " + price;
	}
}
