package javaday7;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListObjectSample {

	public static void main(String[] args) {
		
		Fruit fruit1=new Fruit("Apple",90);
		Fruit fruit2=new Fruit("Mango",60);
		Fruit fruit3=new Fruit("Papaya",70);

		List<Fruit> fruits=new ArrayList<Fruit>();
		
		fruits.add(fruit1);
		fruits.add(fruit2);
		fruits.add(fruit3);
		
//		Iterator fruititr=fruits.iterator();
//		while (fruititr.hasNext())
//		{
//		
//			System.out.println(fruititr.next());
//			
//		}
		
		for(Fruit f : fruits)
		{
			if (f.getPrice()>80)
			System.out.println(f);
		}
		
	}
	
	

}
