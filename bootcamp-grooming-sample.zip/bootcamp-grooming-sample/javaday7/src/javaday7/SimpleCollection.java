package javaday7;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SimpleCollection {

	public static void main(String[] args) {
		 
		List colors=new ArrayList();
		//hetrogenious collection
		colors.add("REd");
		colors.add("Blue");
		colors.add("Green");
		colors.add(10);
		
		Iterator coloriterator=colors.iterator();
		
		while (coloriterator.hasNext())
		{
		
		
			if(coloriterator.next().toString().equals("Blue"))
				coloriterator.remove();
		}
          	
		
//		coloriterator=colors.iterator();
//		while (coloriterator.hasNext())
//		{
//		
//			System.out.println(coloriterator.next());
//			
//		}
//   for()
		  
	
		//Generics
		
		List<String> fruits=new ArrayList<String>();
		
		fruits.add("Apple");
		fruits.add("Banana");
		fruits.add("Mango");
		fruits.add("Papaya");
		
	
		for(String frt : fruits)
		{
			System.out.println(frt);
		}
		
		
		
	}

}
