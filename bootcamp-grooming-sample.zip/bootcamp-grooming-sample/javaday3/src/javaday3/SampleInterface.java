package javaday3;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

interface iDisplay
{
   void storeData();	
}

class Person implements iDisplay
{
	
	void addData()
	{
		
	}

	@Override
	public void storeData() {
System.out.println("Store the data in file");		
	}
	
}

class Student implements iDisplay
{

	@Override
	public void storeData() {
	System.out.println("Store data in database");
		
	}
	
}

class Vehicle implements iDisplay
{

	@Override
	public void storeData() {
	System.out.println("Keep the parts in godown");
		
	}
	
}

public class SampleInterface {

	public static void main(String[] args) {

		
		Vehicle veh=new Vehicle(); //tightly

		
		
		
		iDisplay disobj=new Student(); //loosly
		
 		
		
		List list=new LinkedList();
		
		LinkedList list1=new LinkedList();
		
		
		
		getStoreProcess(new Vehicle());
		
		getStoreProcess(new Student()); 

	}

	static  void getStoreProcess(iDisplay display)
	  {
		     
		  display.storeData();
	  }
	
}
