package javaday3;

abstract class BillPayment
{
	abstract void payBill();
	void display()
	{
		System.out.println("LIC payment");
	}
	
}

class OnlineMode extends BillPayment
{
	String mailid;
	int phonenumber;
	
	void login()
	{
		System.out.println("valid login");
	}
	void payBill()
	{
		System.out.println("u have 10% discount");
		
	}
		

}

class InpersonMode extends BillPayment 
{
	
	void payBill()
	{
		System.out.println("you need to pay before 10th");
	}
}


public class AbstractSample {

	public static void main(String[] args) {
OnlineMode online=new OnlineMode();
//online.payBill();

InpersonMode inobj=new InpersonMode();
//inobj.payBill();

//online.display();
BillPayment billobj;

billobj=new OnlineMode();

 

 billobj=new InpersonMode();
 
 
 BillingProcess(new OnlineMode());



	}

	static void BillingProcess(OnlineMode onlineobj)
	{
		onlineobj.payBill();
		onlineobj.login();
	}
	
	
	
	
}
