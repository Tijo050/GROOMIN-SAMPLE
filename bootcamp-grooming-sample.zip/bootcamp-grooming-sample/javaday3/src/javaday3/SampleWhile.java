package javaday3;

import java.util.Scanner;

public class SampleWhile {

	public static void main(String[] args) {
		
		System.out.println("Enter number");
		Scanner scan=new Scanner(System.in);
		int num=scan.nextInt();
		
		while(num>0)
		{
			System.out.println("weclome " + num);
			num--;
			
		}
		
	}

}
