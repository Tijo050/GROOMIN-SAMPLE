package javaday9;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Book
{
	int bookid;
String bname;

	 public String getBname() {
	return bname;
}
public void setBname(String bname) {
	this.bname = bname;
}
	public Book (int bookid,String name)
	 {
		 this.bookid=bookid;
		 this.bname=name;
	 }
	public int getBookid() {
		return bookid;
	}

	public void setBookid(int bookid) {
		this.bookid = bookid;
	}
	
}

class Check implements Comparator
{

	@Override
	
	public int compare(Object obj1, Object obj2) {
    Book e1=(Book)obj1;
    Book e2=(Book)obj2;
		
		return e1.getBookid()-e2.getBookid();
	}
	
}

// Sorting using Comparable

class Employee implements Comparable
{ 


	 int id;
	 public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	String name;
	 public Employee(int id,String nm)
	 {
		 this.id=id;
		 this.name=nm;
	 }
	
 
	public int compareTo(Object obj) {
	   Employee empobj=(Employee)obj;
	   
	   if(this.id==empobj.getId())
		   return 0;
	   else
		  return empobj.getId()-this.id;
	 
	}
	public String toString()
	{
		return " Id " + id  + " name " + name;
	}
	
}

public class SampleSort {

	public static void main(String[] args) {
	 
		List<Employee> employees=new ArrayList<Employee>();
		
		Employee e1=new Employee(10,"Anju");
		Employee e2=new Employee(40,"Vikram");
		Employee e3=new Employee(15,"Raju");
		Employee e4=new Employee(30,"Vimal");
		
		
		employees.add(e1);
		employees.add(e2);
		employees.add(e3);
		employees.add(e4);
		 
		Collections.sort(employees);
		
		for(Employee e : employees)
			System.out.println(e);
		

		Check ccompare=new Check();
		
		Book b1=new Book(10,"ASP");
		Book b2=new Book(5,"C#");
		Book b3=new Book(20,"XML");
		
		List<Book> books=new ArrayList<Book>();
		
		
		
		books.add(b1);
		books.add(b2);
		books.add(b3);
		
		books.sort(ccompare);
		
		
		
		for(Book b : books)
			System.out.println(b.getBookid() + b.getBname() );
	}

}
