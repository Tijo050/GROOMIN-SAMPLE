import java.util.Scanner;

class Employee
{
  String name;
  int empid;
  int salary;
    void showDetails()
    {
    	int a;
    	System.out.println(name + "Salary " + salary);
    }
    
     long findPercent()
      {
    	 return salary*10/100;
      }
     
     int findTaxafterdeduct(int tax, int pf)
     {
    	 return salary + salary * tax/100-pf;
     }
     
     
    	
}
public class SampleBig {

	public static void main(String[] args) {
 		
//		int n=0;
//		long num=0;
//		short ans=0;
//		float amount=12.4f;
//		double salary=12.45d;
//		boolean choice=false;

		Scanner scan=new Scanner(System.in);
		
		System.out.println("enter id,salary and name");
		// Employee emp; // object
		Employee emp=new Employee(); // instantiation memory will be alloted for variables
		
		emp.empid=scan.nextInt();
		emp.salary=scan.nextInt();
		emp.name=scan.next();
		
		
		
		emp.showDetails(); // calling a method
		
		long ans=emp.findPercent();  // invoking method
		
		System.out.println("salary 10% " + ans);
	int tax=emp.findTaxafterdeduct(8,1000);
	
	System.out.println("pecentage after tax" + tax);
	
		
	}

}


/*



*/
